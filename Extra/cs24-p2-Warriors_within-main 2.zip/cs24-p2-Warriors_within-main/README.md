# cs24-p2-Warriors_within

# Project Name
EcoSync: Revolutionizing Waste Management in Dhaka North City Corporation

## Installation
To get started, follow these steps:

### 1. Download Requirements
Open your terminal and download all the requirements.

#### Linux Command:
pip3 install -r requirements.txt

### 2. Run the Application
After installing the requirements, run the `app.py` file.

#### Linux Command:
python3 app.py


## License
This project is licensed under the [MIT License](LICENSE).


