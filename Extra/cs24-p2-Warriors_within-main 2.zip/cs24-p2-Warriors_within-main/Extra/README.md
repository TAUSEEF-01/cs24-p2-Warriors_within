# Admin-Dashboard-Top
A full dashboard design with css grid

This exercise is an html and css admin dashboard.
For this I have used CSS Grid and the result should be similar to the following image:

![Example of admin dashboard The Odin Project](https://cdn.statically.io/gh/TheOdinProject/curriculum/43cc6ab69fdfbef40d431a65677d2144668930ac/intermediate_html_css/grid/project_admin_dashboard/imgs/dashboard-project.png)

Assigments:

* [Project: Admin Dashboard](https://www.theodinproject.com/lessons/node-path-intermediate-html-and-css-admin-dashboard)



See the project:

* [Live Preview](https://carlosfrontend.github.io/admin-dashboard-top/) :desktop_computer:

Happy Coding! :rocket:
